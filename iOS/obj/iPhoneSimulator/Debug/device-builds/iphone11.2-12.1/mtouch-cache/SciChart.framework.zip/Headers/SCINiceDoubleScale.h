//******************************************************************************
// SCICHART® Copyright SciChart Ltd. 2011-2018. All rights reserved.
//
// Web: http://www.scichart.com
// Support: support@scichart.com
// Sales:   sales@scichart.com
//
// SCINiceDoubleScale.h is part of SCICHART®, High Performance Scientific Charts
// For full terms and conditions of the license, see http://www.scichart.com/scichart-eula/
//
// This source code is protected by international copyright law. Unauthorized
// reproduction, reverse-engineering, or distribution of all or any portion of
// this source code is strictly prohibited.
//
// This source code contains confidential and proprietary trade secrets of
// SciChart Ltd., and should at no time be copied, transferred, sold,
// distributed or made available without express written permission.
//******************************************************************************

#import <Foundation/Foundation.h>
#import "SCINiceScale.h"

@class SCIDoubleAxisDelta;
@class SCIDoubleRange;

@interface SCINiceDoubleScale : NSObject <SCINiceScaleProtocol> {
@protected
    int _minorsPerMajor;
    double _minDelta;
    double _maxDelta;
    SCIDoubleRange * _niceRange;
    uint _maxTicks;
}

-(id) initWithMin:(double)min Max:(double)max MinorsPerMajor:(int)minorsPerMajor MaxTicks:(int)maxTicks;

-(SCIDoubleRange*) niceRange;

-(double) niceNumWithRange:(double)range Round:(BOOL)round;

@end
